
# -*- coding: utf-8 -*-
"""
Created on Sat Dec  7 19:21:41 2024

@author: Paolo Castellini
"""

import functions
import pandas as pd
import csv
import os
import platform
import time

##############################################################################################################
# API Key settings
API_KEY = "c81e40b973484fb83db5c697eadc3bea" # Chiave API Cast

# API_KEY = "18acfcf2e6f1ef665eec335c2fc40fcc" # Chiave API Forlano

# API_KEY="10f7de16ece6898e37b7f9c6d6a68eb7" # Chiave API Caputo

# API_KEY="a4be5d6403465914a622246057f086e0" # Chiave API Scocco 1

# API_KEY="d1dd3948f277cd381a11337c51d72f67" # Chiave API Scocco 2



##############################################################################################################
# Author XLS and CSV articles file name settings
reference_name = "misure"
xls_file_name = reference_name + ".xlsx"
csv_file_name = reference_name + ".csv"
log_file_name = reference_name + "_log.txt"
skipped_file_name = reference_name + "_skip.txt"

if platform.system() == "Windows":
    base_dir_path = r"C:\Users\CMM\Desktop\20250327_Bibliometry\Dati"
    # base_dir_path = r"F:\Alberto\Attivita\UnivPM\20250327_Bibliometry\Dati"
# else:
    #base_dir_path = "/home/aisha/Documents/Cast/Test_sam2-main/notebooks/videos"

xls_file_path = os.path.join( base_dir_path, xls_file_name )
csv_file_path = os.path.join( base_dir_path, csv_file_name )
log_file_path = os.path.join( base_dir_path, log_file_name )
skipped_file_path = os.path.join( base_dir_path, skipped_file_name )


print(f"\n\nFiles to be processed\n- CSV article data file name: {csv_file_path}\n- XLS authors file name: {xls_file_path}\n- LOG file name: {log_file_path}")

###################################################################################
# Sets up the log file with the time marker
functions.log_file_setup( log_file_path )

#############################
# Sets up the log file for the skipped authors 
functions.skipped_file_setup( skipped_file_path )


##########################################
# Sets up the CSV file 
# - creating it if it doesn't exist 
# - writing the header if it's empty
# - cleaning it from wrong characters (single and double quotes)
functions.CSV_file_setup( csv_file_path )


#####################################################
# Manages the problem of the last author in the CSV file, because there could be a partial download.
# The user can choose to delete the last author's data, or stop the execution
# If chooses to proceed and delete, the author's name, surname and institution are given back from the function  
last_CSV_author_name , last_CSV_author_surname, last_CSV_author_institution = functions.manage_last_author_articles( csv_file_path )

###########################################################
# Load all the authors XLS rows in a dictionary of list of strings, with keys called name, surname and institution 
# The first elements are the one previously deleted from the CSV file in the previous step

XLS_authors = functions.XLS_authors_list( xls_file_path, last_CSV_author_name , last_CSV_author_surname, last_CSV_author_institution ) # Load the authors from the XLS file


#############################################################
# Loads the CSV file in a dictionary of list of strings, with keys called name, surname and institution
# The first elements are the one previously deleted from the CSV file in the previous step
articles = functions.load_CSV_articles(csv_file_path)


###
# DELETE
##############################################################################################################
# Loads all the articles from the CSV file in a dictionary of list of strings, with keys called name, surname and institution 
# The first elements are the one previously deleted from the CSV file in the previous step
#articles_authors_unique = functions.articles_authors_list( csv_file_path )


##############################################################################################################
# Scopus search for each author by Surname Name and Institution of the author
print("Inizio ricerca su Scopus\n\n")

for k in range( 0, len( XLS_authors["name"] ) ):
    # Load the current author's data from the XLS dictionary
    author_name         = XLS_authors["name"       ][k]            
    author_surname      = XLS_authors["surname"    ][k]      
    author_institution  = XLS_authors["institution"][k] 
    
    
    # Check if the author is already in the CSV file of articles
    # If the author is already in the CSV file, skip it and go to the next one
    # We are sure that the last article in CSV file is the last one from the last author already processed 
    #######
    # DELETE
    """
    if ( functions.is_written_author( author_surname, author_name, author_institution, articles_authors_unique ) ) : # Skips the author if it is already written in the CSV file of articles
        print("\n\nThe following author is skipped: the search has been done and data are already written in the CSV file of articles")
        print(f"Name: {author_name}\nSurname: {author_surname}\nInstitution: {author_institution}\n")
        continue    
    """    

    time.sleep(3)
    author_data_elements = functions.search_author_with_institution( author_name, author_surname, author_institution, API_KEY )     # Search for the author in Scopus, using name, surname and institution
    
    author_search_results = author_data_elements.get( "search-results", {} ).get( "entry", [] )

    ###################################
    # Loop to print a row of author's data, one for each affiliation istitution  
    for entry in author_search_results : 
        surname           = entry.get( 'preferred-name'     , {}).get( 'surname'         )
        name              = entry.get( 'preferred-name'     , {}).get( 'given-name'      )
        affiliation       = entry.get( 'affiliation-current', {}).get( 'affiliation-name')
        
        if surname is None:
            break
        else:
            surname = surname.lower()
            name = name.lower()
            affiliation = affiliation.lower()
            
        author_id_obj     = entry.get( 'dc:identifier'          )  
        author_id_string = str( author_id_obj )
        author_id = author_id_string[ 10: ]   # The id code is in the form 'AUTHOR_ID:58119182300'
        
        print("\n\n\n####################\n")
        print( "NEXT AUTHOR QUERY")            
        print(f"Name        : { name }")
        print(f"Surname     : { surname }")
        print(f"Institution : { affiliation }")
        print(f"Scopus ID   : { author_id }\n")
        
        with open(log_file_path, "a", encoding="utf-8") as file:
            file.write( "\n\n\n####################\n\n")
            file.write( "NEXT AUTHOR QUERY\n\n")   
            file.write(f"Name        : { name }\n")
            file.write(f"Surname     : { surname }\n")
            file.write(f"Institution : { affiliation }\n")
            file.write(f"Scopus ID   : { author_id }\n\n")
        
        if not ( ( affiliation in author_institution ) or ( author_institution in affiliation ) ) :
            print( "This author's record has a different affiliation institution from the one searched in the XLS file, so will be skipped\n")
            with open(log_file_path, "a", encoding="utf-8") as file:
                file.write( "This author's record has a different affiliation institution from the one searched in the XLS file, so will be skipped\n")
            with open(skipped_file_path, "a", encoding="utf-8") as file:
                file.write("\n\n####################\n")
                file.write( "\nSKIPPED AUTHOR\n\n")   
                file.write(f"Name        : { name }\n")
                file.write(f"Surname     : { surname }\n")
                file.write(f"Institution from XLS file : { affiliation }\n")
                file.write(f"Institution from Scopus : { author_institution }\n")
                file.write(f"Scopus ID   : { author_id }\n\n")
            continue
        else:
            print( f"This author's SCOPUS record has the same affiliation [{affiliation}] as the one [{author_institution}] in the XLS file.\nThis author will be processed\n")
            with open(log_file_path, "a", encoding="utf-8") as file:
                file.write(f"This author's SCOPUS record has the same affiliation [{affiliation}] as the one [{author_institution}] in the XLS file.\nThis author will be processed\n")


        author_articles = functions.get_author_articles( author_id , API_KEY )            # Gets the list of author articles
        
        articles_data = []
        print(f"This author has {len(author_articles)} articles with the institution {author_institution}\n")
        with open(log_file_path, "a", encoding="utf-8") as file:
                file.write(f"This author has {len(author_articles)} articles with the institution {author_institution}\n")
        
        for k, author_article in enumerate( author_articles ):       

            author_article_elements = list( author_article.values() )  
            
            author_article_title    = author_article_elements[0]
            author_article_num_aut  = author_article_elements[1]
            print(f"\n\n##############\nAuthor: {author_name} {author_surname} - Institution: {author_institution}\n")
            print(f"Article n. {k+1}/{len(author_articles)} - Title: {author_article_title}\n" )
            with open(log_file_path, "a", encoding="utf-8") as file:
                file.write(f"\n\n##############\nAuthor: {author_name} {author_surname} - Institution: {author_institution}\n")
                file.write(f"Article n. {k+1}/{len(author_articles)} - Title: {author_article_title}\n" )
                    
            author_article_num_cit  = author_article_elements[2]
            author_article_doi      = author_article_elements[3]
            author_article_eid      = author_article_elements[4]  

            # Skips the article if it is already in the CSV file
            if functions.is_written_CSV_article( articles, author_article_eid ) :
                print("This article has already been processed and written in the CSV file, so it will be skipped\n")
                with open(log_file_path, "a", encoding="utf-8") as file:
                    file.write("This article has already been processed and written in the CSV file, so it will be skipped\n")
                continue
            
            time.sleep(15) # Rallenta il processo di 30 secondi per evitare di superare il limite di richieste API    
            
            author_article_authors = functions.get_authors_by_eid( author_article_eid, API_KEY )
            author_article_num_aut = len( author_article_authors )      
            
            article_references = functions.get_references_by_doi( author_article_doi ) # Gets the list of reference articles
            author_article_num_references = len( article_references )          

            author_article_year = functions.get_article_year_by_eid( author_article_eid, API_KEY )

            # Gets the dois codes for the citing articles of the selected article
            author_article_citing_dois = functions.get_citing_articles( author_article_eid , API_KEY )
            # author_article_citing_dois = functions.get_citing_articles( author_article_eid , API_KEY )
            
            author_article_num_ref , author_article_citing_years = functions.manage_citing_articles( author_article_citing_dois)

            current_article_data = {"name":         author_name ,
                                    "surname":      author_surname, 
                                    "institution":  functions.clean_field( author_institution ),
                                    "author_id":    author_id,
                                    "article_eid":  author_article_eid,
                                    "year":         author_article_year,
                                    "num_aut":      author_article_num_aut, 
                                    "num_cit":      author_article_num_cit, 
                                    "article_refs": author_article_num_references,
                                    "citing_years": functions.clean_field
                                    ( author_article_citing_years ), 
                                    "num_ref_in_citing": author_article_num_ref  }
                       
            with open(csv_file_path, "a", encoding="utf-8", newline="") as file:
                writer = csv.DictWriter(file, delimiter="|", fieldnames=["name", "surname", "institution", "author_id", "article_eid", "year", "num_aut", "num_cit", "article_refs", "num_ref_in_citing", "citing_years"])       
                writer.writerows( [current_article_data] )
            
            articles_data.append( current_article_data )
            articles.append( current_article_data )
            
            with open(log_file_path, "a", encoding="utf-8") as file:
                file.write( f"Number of citations: {author_article_num_cit}\n")
                file.write( f"Number of references: {author_article_num_references}\n")
                file.write( f"Citing years: {author_article_citing_years}\n")
        
        ###
        # DELETE
        #articles_authors_unique["name"].append( author_name )
        #articles_authors_unique["surname"].append( author_surname )
        #articles_authors_unique["institution"].append( author_institution )
               
        
        num_articles = len( articles_data )
        print(f"\n\n############\nAuthor:\nName: { author_name }\nSurname: { author_surname}\nInstitution: { author_institution}\nSaved {num_articles} articles\n")
        for k in range (num_articles):
            print( f"Art. {k+1}/ {num_articles} ) {articles_data[k]}\n")
        with open(log_file_path, "a", encoding="utf-8") as file:
            file.write(f"\n\n############\nAuthor:\nName: { author_name }\nSurname: { author_surname}\nInstitution: { author_institution}\nSaved {num_articles} articles\n")
            for k in range (num_articles):
                file.write( f"Art. {k+1}/ {num_articles} ) {articles_data[k]}\n")
                

print(f"\n\nEnd of the search for author's articles in Scopus\n")





